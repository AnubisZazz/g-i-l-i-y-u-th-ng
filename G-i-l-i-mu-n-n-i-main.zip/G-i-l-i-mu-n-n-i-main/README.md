# G-i-l-i-mu-n-n-i
